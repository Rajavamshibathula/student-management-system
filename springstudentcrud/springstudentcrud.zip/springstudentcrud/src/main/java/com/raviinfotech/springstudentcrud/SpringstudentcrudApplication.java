package com.raviinfotech.springstudentcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringstudentcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringstudentcrudApplication.class, args);
	}

}
