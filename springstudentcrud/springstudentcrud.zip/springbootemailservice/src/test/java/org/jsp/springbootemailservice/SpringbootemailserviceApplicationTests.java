package org.jsp.springbootemailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootemailserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
